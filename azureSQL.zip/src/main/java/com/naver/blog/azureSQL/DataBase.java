package com.naver.blog.azureSQL;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DataBase {
	
	
	PreparedStatement pstmt;
	Connection conn;
	ResultSet rs;
	
	
	public void dbConnect() {
		
		String url = "jdbc:sqlserver://lyra9409.database.windows.net:1433;database=lyra;user=lyra9409@lyra9409;password=distributed494316runSQL494316;encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;";
		
		
		try {
			
			conn = DriverManager.getConnection(url);
			String schema = conn.getSchema();
			
			System.out.println("--------------------" + schema);
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	
	public void insertDB(int a, String b) {
		
		String sql = "INSERT INTO test VALUES(?,?)";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, a);
			pstmt.setString(2, b);
			
			pstmt.execute();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public void deleteDB(int a) {
		
		String sql = "DELETE FROM test WHERE id = ?";
		
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, a);
			
			
			pstmt.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
}
