package com.naver.blog.azureSQL;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        
    	DataBase db = new DataBase();
    	db.dbConnect();
    	
    	db.deleteDB(2);
    }
}
